/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../LibDEMO2/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[21];
    char stringdata0[378];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 24), // "on_submitAddBook_clicked"
QT_MOC_LITERAL(2, 36, 0), // ""
QT_MOC_LITERAL(3, 37, 21), // "on_deleteBook_clicked"
QT_MOC_LITERAL(4, 59, 19), // "on_findBook_clicked"
QT_MOC_LITERAL(5, 79, 24), // "on_submitUserAdd_clicked"
QT_MOC_LITERAL(6, 104, 19), // "on_findUser_clicked"
QT_MOC_LITERAL(7, 124, 21), // "on_deleteUser_clicked"
QT_MOC_LITERAL(8, 146, 25), // "on_giveBookToUser_clicked"
QT_MOC_LITERAL(9, 172, 29), // "on_returnBookFromUser_clicked"
QT_MOC_LITERAL(10, 202, 24), // "on_editUserBooks_clicked"
QT_MOC_LITERAL(11, 227, 20), // "dataValidation_books"
QT_MOC_LITERAL(12, 248, 6), // "search"
QT_MOC_LITERAL(13, 255, 20), // "dataValidation_users"
QT_MOC_LITERAL(14, 276, 17), // "dataInFileReplace"
QT_MOC_LITERAL(15, 294, 10), // "inFileName"
QT_MOC_LITERAL(16, 305, 11), // "outFileName"
QT_MOC_LITERAL(17, 317, 9), // "searchRow"
QT_MOC_LITERAL(18, 327, 10), // "replaceRow"
QT_MOC_LITERAL(19, 338, 19), // "on_editBook_clicked"
QT_MOC_LITERAL(20, 358, 19) // "on_editUser_clicked"

    },
    "MainWindow\0on_submitAddBook_clicked\0"
    "\0on_deleteBook_clicked\0on_findBook_clicked\0"
    "on_submitUserAdd_clicked\0on_findUser_clicked\0"
    "on_deleteUser_clicked\0on_giveBookToUser_clicked\0"
    "on_returnBookFromUser_clicked\0"
    "on_editUserBooks_clicked\0dataValidation_books\0"
    "search\0dataValidation_users\0"
    "dataInFileReplace\0inFileName\0outFileName\0"
    "searchRow\0replaceRow\0on_editBook_clicked\0"
    "on_editUser_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   84,    2, 0x08 /* Private */,
       3,    0,   85,    2, 0x08 /* Private */,
       4,    0,   86,    2, 0x08 /* Private */,
       5,    0,   87,    2, 0x08 /* Private */,
       6,    0,   88,    2, 0x08 /* Private */,
       7,    0,   89,    2, 0x08 /* Private */,
       8,    0,   90,    2, 0x08 /* Private */,
       9,    0,   91,    2, 0x08 /* Private */,
      10,    0,   92,    2, 0x08 /* Private */,
      11,    1,   93,    2, 0x08 /* Private */,
      13,    1,   96,    2, 0x08 /* Private */,
      14,    4,   99,    2, 0x08 /* Private */,
      19,    0,  108,    2, 0x08 /* Private */,
      20,    0,  109,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Bool, QMetaType::Bool,   12,
    QMetaType::Bool, QMetaType::Bool,   12,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,   15,   16,   17,   18,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_submitAddBook_clicked(); break;
        case 1: _t->on_deleteBook_clicked(); break;
        case 2: _t->on_findBook_clicked(); break;
        case 3: _t->on_submitUserAdd_clicked(); break;
        case 4: _t->on_findUser_clicked(); break;
        case 5: _t->on_deleteUser_clicked(); break;
        case 6: _t->on_giveBookToUser_clicked(); break;
        case 7: _t->on_returnBookFromUser_clicked(); break;
        case 8: _t->on_editUserBooks_clicked(); break;
        case 9: { bool _r = _t->dataValidation_books((*reinterpret_cast< bool(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 10: { bool _r = _t->dataValidation_users((*reinterpret_cast< bool(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 11: _t->dataInFileReplace((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4]))); break;
        case 12: _t->on_editBook_clicked(); break;
        case 13: _t->on_editUser_clicked(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 14)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 14;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
